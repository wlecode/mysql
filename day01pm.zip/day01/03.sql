#显示所有数据库
#SHOW DATABASES;
/*
USE phpmyadmin; 
DESC pma__recent;
*/
