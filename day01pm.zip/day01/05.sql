#丢弃数据库，如果存在tedu 
DROP DATABASE IF EXISTS tedu;
#创建数据库tedu
CREATE DATABASE tedu;