show databases;
show 
databases;
show databases;
use phpmyadmin;
show tables;